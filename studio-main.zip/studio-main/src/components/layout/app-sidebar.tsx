'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  BookOpen,
  Camera,
  ClipboardCheck,
  LayoutDashboard,
  MessageSquare,
  Notebook,
} from 'lucide-react';

import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  SidebarGroup,
} from '@/components/ui/sidebar';
import { GavelIcon } from '@/components/icons';

const menuItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/tutor', label: 'AI Legal Tutor', icon: MessageSquare },
  { href: '/image-analysis', label: 'Image Analysis', icon: Camera },
  { href: '/topics', label: 'Browse Topics', icon: BookOpen },
  { href: '/cases', label: 'Case Law', icon: GavelIcon },
  { href: '/exam', label: 'Exam Section', icon: ClipboardCheck },
  { href: '/notes', label: 'My Notes', icon: Notebook },
];

export function AppSidebar() {
  const pathname = usePathname();

  return (
    <Sidebar>
      <SidebarHeader>
        <div className="flex items-center gap-2">
          <h1 className="font-headline text-2xl font-bold text-sidebar-primary">LexNaija AI</h1>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          {menuItems.map((item) => (
            <SidebarMenuItem key={item.href}>
              <Link href={item.href} legacyBehavior passHref>
                <SidebarMenuButton
                  isActive={pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href))}
                  tooltip={{ children: item.label }}
                >
                  <item.icon />
                  <span>{item.label}</span>
                </SidebarMenuButton>
              </Link>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter>
        <SidebarGroup>
          <div className="rounded-lg bg-sidebar-accent p-4 text-sm text-sidebar-accent-foreground">
            <h3 className="font-semibold">Upgrade to Pro</h3>
            <p className="mt-1 text-xs text-muted-foreground">
              Unlock unlimited queries, full case analysis, and more.
            </p>
            <Link href="#" legacyBehavior passHref>
              <SidebarMenuButton asChild size="sm" className="mt-3 w-full">
                <a className="bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90">
                  Upgrade
                </a>
              </SidebarMenuButton>
            </Link>
          </div>
        </SidebarGroup>
      </SidebarFooter>
    </Sidebar>
  );
}
