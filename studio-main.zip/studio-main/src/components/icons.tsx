import type { SVGProps } from 'react';

export function GavelIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="m14 13-7.5 7.5" />
      <path d="m16 11 8 8" />
      <path d="m21.5 16.5-1.5-1.5" />
      <path d="m12 15 1-1" />
      <path d="m3 21 6-6" />
      <path d="m8 16 1-1" />
      <path d="m9 2-6 6" />
      <path d="m16 9 3-3" />
      <path d="m13 6 3-3" />
      <path d="m10 3 3 3" />
    </svg>
  );
}
