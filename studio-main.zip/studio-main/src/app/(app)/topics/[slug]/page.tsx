import { notFound } from 'next/navigation';
import { lawTopics } from '@/lib/data';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import {
  BookCopy,
  Gavel,
  Lightbulb,
  ListOrdered,
  BookText,
  Youtube,
} from 'lucide-react';

export async function generateStaticParams() {
  return lawTopics.map((topic) => ({
    slug: topic.slug,
  }));
}

export default function TopicDetailPage({
  params,
}: {
  params: { slug: string };
}) {
  const topic = lawTopics.find((t) => t.slug === params.slug);

  if (!topic) {
    notFound();
  }

  return (
    <div className="space-y-8">
      <div>
        <Badge variant="secondary">{topic.category}</Badge>
        <h1 className="mt-2 font-headline text-4xl font-bold tracking-tight md:text-5xl">
          {topic.title}
        </h1>
        <p className="mt-4 max-w-3xl text-lg text-muted-foreground">
          {topic.overview}
        </p>
      </div>

      <Accordion type="multiple" defaultValue={['definitions', 'elements']} className="w-full max-w-3xl">
        <AccordionItem value="definitions">
          <AccordionTrigger className="text-xl font-semibold">
            <BookText className="mr-2 h-5 w-5" /> Key Definitions
          </AccordionTrigger>
          <AccordionContent>
            <dl className="space-y-4 p-2">
              {topic.definitions.map((def) => (
                <div key={def.term}>
                  <dt className="font-semibold">{def.term}</dt>
                  <dd className="mt-1 text-muted-foreground">
                    {def.definition}
                  </dd>
                </div>
              ))}
            </dl>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="elements">
          <AccordionTrigger className="text-xl font-semibold">
            <ListOrdered className="mr-2 h-5 w-5" /> Essential Elements
          </AccordionTrigger>
          <AccordionContent>
            <ul className="list-inside list-disc space-y-2 p-2 text-muted-foreground">
              {topic.essentialElements.map((element, index) => (
                <li key={index}>{element}</li>
              ))}
            </ul>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="statutes">
          <AccordionTrigger className="text-xl font-semibold">
            <BookCopy className="mr-2 h-5 w-5" /> Relevant Statutes
          </AccordionTrigger>
          <AccordionContent>
            <ul className="space-y-2 p-2">
              {topic.relevantStatutes.map((statute, index) => (
                <li key={index}>
                  <a href={statute.link} className="text-primary hover:underline">
                    {statute.name}
                  </a>
                </li>
              ))}
            </ul>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="cases">
          <AccordionTrigger className="text-xl font-semibold">
            <Gavel className="mr-2 h-5 w-5" /> Leading Cases
          </AccordionTrigger>
          <AccordionContent>
            <ul className="space-y-2 p-2 text-muted-foreground">
              {topic.leadingCases.map((c, index) => (
                <li key={index}>
                  <span className="font-medium text-foreground">{c.name}</span>{' '}
                  {c.citation}
                </li>
              ))}
            </ul>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="tips">
          <AccordionTrigger className="text-xl font-semibold">
            <Lightbulb className="mr-2 h-5 w-5" /> Exam Tips
          </AccordionTrigger>
          <AccordionContent>
            <ul className="list-inside list-disc space-y-2 p-2 text-muted-foreground">
              {topic.examTips.map((tip, index) => (
                <li key={index}>{tip}</li>
              ))}
            </ul>
          </AccordionContent>
        </AccordionItem>

        {topic.youtubeVideos.length > 0 && (
          <AccordionItem value="videos">
            <AccordionTrigger className="text-xl font-semibold">
              <Youtube className="mr-2 h-5 w-5" /> AI Recommended Videos
            </AccordionTrigger>
            <AccordionContent>
              <div className="grid grid-cols-1 gap-4 p-2 sm:grid-cols-2">
                {topic.youtubeVideos.map((video) => (
                  <div key={video.id} className="space-y-2">
                     <div className="aspect-video overflow-hidden rounded-lg">
                        <iframe
                            className="h-full w-full"
                            src={`https://www.youtube.com/embed/${video.id}`}
                            title={video.title}
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                        ></iframe>
                     </div>
                     <p className="text-sm font-medium">{video.title}</p>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        )}
      </Accordion>
    </div>
  );
}
