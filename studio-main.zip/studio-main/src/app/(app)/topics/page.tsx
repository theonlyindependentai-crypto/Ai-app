import Link from 'next/link';
import { lawTopics } from '@/lib/data';
import {
  Card,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';

export default function TopicsPage() {
  const topicsByCategory = lawTopics.reduce((acc, topic) => {
    (acc[topic.category] = acc[topic.category] || []).push(topic);
    return acc;
  }, {} as Record<string, typeof lawTopics>);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-headline text-3xl font-bold tracking-tight md:text-4xl">
          Browse Legal Topics
        </h1>
        <p className="mt-2 text-muted-foreground">
          Explore our curated library of Nigerian law subjects.
        </p>
      </div>

      {Object.entries(topicsByCategory).map(([category, topics]) => (
        <div key={category}>
          <h2 className="mb-4 font-headline text-2xl font-semibold">
            {category}
          </h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {topics.map((topic) => (
              <Link href={`/topics/${topic.slug}`} key={topic.id} className="group">
                <Card className="flex h-full flex-col justify-between transition-all duration-200 ease-in-out hover:border-primary hover:shadow-md">
                  <CardHeader>
                    <CardTitle>{topic.title}</CardTitle>
                    <CardDescription className="line-clamp-3 pt-2">
                      {topic.overview}
                    </CardDescription>
                  </CardHeader>
                  <div className="flex justify-end p-4 pt-0">
                    <ArrowRight className="h-5 w-5 text-muted-foreground transition-transform duration-300 group-hover:translate-x-1" />
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
