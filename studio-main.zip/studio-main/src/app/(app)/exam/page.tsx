'use client';

import { useState, useEffect } from 'react';
import { examQuestions as allQuestions } from '@/lib/data';
import type { ExamQuestion, ExamMode, ExamSettings } from '@/lib/types';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { CheckCircle, XCircle, Clock, Target, Repeat, Timer, InfinityIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type GameState = 'start' | 'playing' | 'finished';
type AnswerState = {
  questionId: string;
  selectedAnswer: number;
  isCorrect: boolean;
};

const TIMED_SESSION_DURATION = 20 * 60; // 20 questions, 1 minute per question

export default function ExamPage() {
  const [gameState, setGameState] = useState<GameState>('start');
  const [examSettings, setExamSettings] = useState<ExamSettings>({ topic: 'All Topics', mode: 'infinity' });
  const [examQuestions, setExamQuestions] = useState<ExamQuestion[]>([]);
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [answers, setAnswers] = useState<AnswerState[]>([]);
  const [showFeedback, setShowFeedback] = useState(false);
  
  const [timeLeft, setTimeLeft] = useState(TIMED_SESSION_DURATION);

  useEffect(() => {
    if (gameState === 'playing' && examSettings.mode === 'timed') {
      if (timeLeft <= 0) {
        setGameState('finished');
        return;
      }
      const timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [gameState, examSettings.mode, timeLeft]);
  

  const topics = ['All Topics', ...Array.from(new Set(allQuestions.map(q => q.topic)))];

  const currentQuestion: ExamQuestion | undefined = examQuestions[currentQuestionIndex];
  const score = answers.filter((a) => a.isCorrect).length;

  const handleStart = () => {
    let questionsForExam = examSettings.topic === 'All Topics'
      ? allQuestions
      : allQuestions.filter(q => q.topic === examSettings.topic);

    if (examSettings.mode === 'timed') {
      questionsForExam = questionsForExam.sort(() => 0.5 - Math.random()).slice(0, 20);
      setTimeLeft(questionsForExam.length * 60);
    }
    
    setExamQuestions(questionsForExam);
    setGameState('playing');
    setCurrentQuestionIndex(0);
    setAnswers([]);
    setSelectedOption(null);
    setShowFeedback(false);
  };

  const handleSelectOption = (index: number) => {
    if (showFeedback) return;
    setSelectedOption(index);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === null || !currentQuestion) return;

    const isCorrect = selectedOption === currentQuestion.correctAnswer;
    setAnswers([
      ...answers,
      {
        questionId: currentQuestion.id,
        selectedAnswer: selectedOption,
        isCorrect,
      },
    ]);
    setShowFeedback(true);
  };

  const handleNextQuestion = () => {
    setShowFeedback(false);
    setSelectedOption(null);
    if (currentQuestionIndex < examQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setGameState('finished');
    }
  };
  
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (gameState === 'start') {
    const questionsForTopic = examSettings.topic === 'All Topics' ? allQuestions : allQuestions.filter(q => q.topic === examSettings.topic);
    const timedQuestionsCount = Math.min(questionsForTopic.length, 20);
    
    return (
      <div className="flex flex-col items-center justify-center text-center">
        <h1 className="font-headline text-3xl font-bold tracking-tight md:text-4xl">Exam Section</h1>
        <p className="mt-2 text-muted-foreground">Test your knowledge of Nigerian Law.</p>
        <Card className="mt-8 w-full max-w-lg">
          <CardHeader>
            <CardTitle>Configure Your Quiz</CardTitle>
            <CardDescription>Select a topic and choose your preferred quiz mode.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
             <div className="space-y-2">
                <Label htmlFor="topic-select">Law Topic</Label>
                <Select
                    value={examSettings.topic}
                    onValueChange={(value) => setExamSettings(prev => ({...prev, topic: value}))}
                >
                    <SelectTrigger id="topic-select">
                        <SelectValue placeholder="Select a topic" />
                    </SelectTrigger>
                    <SelectContent>
                        {topics.map(topic => (
                            <SelectItem key={topic} value={topic}>{topic}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
            
            <Tabs 
              defaultValue="infinity" 
              className="w-full" 
              onValueChange={(value) => setExamSettings(prev => ({...prev, mode: value as ExamMode}))}
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="infinity">
                  <InfinityIcon className="mr-2 h-4 w-4"/> Infinity
                </TabsTrigger>
                <TabsTrigger value="timed">
                  <Timer className="mr-2 h-4 w-4"/> Timed
                </TabsTrigger>
              </TabsList>
              <TabsContent value="infinity" className="mt-4">
                  <Card className="border-dashed">
                      <CardHeader className="flex-row items-center gap-4 space-y-0 p-4">
                          <InfinityIcon className="h-10 w-10"/>
                          <div>
                            <CardTitle>Infinity Mode</CardTitle>
                            <CardDescription>Answer all questions on this topic at your own pace.</CardDescription>
                          </div>
                      </CardHeader>
                      <CardFooter className="bg-muted/50 p-4">
                        <div className="flex w-full items-center justify-between text-sm">
                            <div className="flex items-center gap-2">
                                <Target className="h-4 w-4"/>
                                <span className="font-medium">Questions</span>
                            </div>
                            <span className="text-muted-foreground">{questionsForTopic.length}</span>
                        </div>
                      </CardFooter>
                  </Card>
              </TabsContent>
              <TabsContent value="timed" className="mt-4">
                   <Card className="border-dashed">
                      <CardHeader className="flex-row items-center gap-4 space-y-0 p-4">
                           <Timer className="h-10 w-10"/>
                           <div>
                            <CardTitle>Timed Mode</CardTitle>
                            <CardDescription>Answer {timedQuestionsCount} questions with a time limit.</CardDescription>
                          </div>
                      </CardHeader>
                      <CardFooter className="grid grid-cols-2 gap-4 bg-muted/50 p-4 text-sm">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <Target className="h-4 w-4"/>
                                <span className="font-medium">Questions</span>
                            </div>
                            <span className="text-muted-foreground">{timedQuestionsCount}</span>
                        </div>
                         <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <Clock className="h-4 w-4"/>
                                <span className="font-medium">Time</span>
                            </div>
                            <span className="text-muted-foreground">{formatTime(timedQuestionsCount * 60)}</span>
                        </div>
                      </CardFooter>
                  </Card>
              </TabsContent>
            </Tabs>

          </CardContent>
          <CardFooter>
            <Button onClick={handleStart} className="w-full" disabled={questionsForTopic.length === 0}>
              Start Quiz
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  if (gameState === 'finished') {
    return (
        <div className="flex flex-col items-center justify-center text-center">
        <h1 className="font-headline text-3xl font-bold tracking-tight md:text-4xl">Quiz Complete!</h1>
        <Card className="mt-8 w-full max-w-md">
            <CardHeader>
                <CardTitle>Your Score</CardTitle>
                 <CardDescription>{examSettings.topic} - {examSettings.mode === 'timed' ? 'Timed' : 'Infinity'} Mode</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center gap-4">
                <div className="relative h-32 w-32">
                    <svg className="h-full w-full" viewBox="0 0 36 36">
                        <path
                        className="text-border"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        />
                        <path
                        className="text-primary"
                        strokeDasharray={`${(score / examQuestions.length) * 100}, 100`}
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-3xl font-bold">{score}</span>
                        <span className="text-sm text-muted-foreground">/{examQuestions.length}</span>
                    </div>
                </div>
                <p className="text-lg font-medium">{`You answered ${score} out of ${examQuestions.length} questions correctly.`}</p>
            </CardContent>
            <CardFooter>
                <Button onClick={() => setGameState('start')} className="w-full">
                <Repeat className="mr-2 h-4 w-4" />
                Play Again
                </Button>
            </CardFooter>
        </Card>
      </div>
    );
  }
  
  if (!currentQuestion) {
     return (
      <div className="flex flex-col items-center justify-center text-center">
         <h1 className="font-headline text-3xl font-bold tracking-tight md:text-4xl">No Questions</h1>
         <p className="mt-2 text-muted-foreground">There are no questions available for the selected topic.</p>
         <Button onClick={() => setGameState('start')} className="mt-8">Go Back</Button>
      </div>
     )
  }

  return (
    <div className="mx-auto w-full max-w-2xl">
      <div className="mb-4 flex justify-between items-center">
        <div>
            <p className="text-sm text-muted-foreground">
            Question {currentQuestionIndex + 1} of {examQuestions.length}
            </p>
            <p className="text-xs text-muted-foreground">{currentQuestion.topic}</p>
        </div>
        {examSettings.mode === 'timed' && (
             <div className="flex items-center gap-2 rounded-full bg-muted px-3 py-1 text-sm font-medium">
                <Clock className="h-4 w-4" />
                <span>{formatTime(timeLeft)}</span>
            </div>
        )}
      </div>
      <Progress value={((currentQuestionIndex + 1) / examQuestions.length) * 100} className="mb-4 h-2" />

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">{currentQuestion.question}</CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={selectedOption?.toString()}
            onValueChange={(value) => handleSelectOption(parseInt(value))}
            className="space-y-3"
            disabled={showFeedback}
          >
            {currentQuestion.options.map((option, index) => {
              const isCorrect = index === currentQuestion.correctAnswer;
              const isSelected = index === selectedOption;

              return (
                <Label
                  key={index}
                  htmlFor={`option-${index}`}
                  className={cn(
                    "flex items-center gap-3 rounded-md border p-4 cursor-pointer transition-colors hover:bg-accent",
                    showFeedback && isCorrect && "border-green-500 bg-green-500/10 text-green-900 dark:text-green-200",
                    showFeedback && isSelected && !isCorrect && "border-red-500 bg-red-500/10 text-red-900 dark:text-red-200"
                  )}
                >
                  <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                  <span>{option}</span>
                  {showFeedback && isCorrect && <CheckCircle className="ml-auto h-5 w-5 text-green-500" />}
                  {showFeedback && isSelected && !isCorrect && <XCircle className="ml-auto h-5 w-5 text-red-500" />}
                </Label>
              );
            })}
          </RadioGroup>
        </CardContent>
        <CardFooter className="flex flex-col items-stretch gap-4">
          {showFeedback ? (
            <>
              <Alert variant={answers[answers.length-1]?.isCorrect ? 'default' : 'destructive'} className={cn(
                  answers[answers.length-1]?.isCorrect ? "bg-green-500/10 border-green-500" : ""
              )}>
                <AlertTitle className="flex items-center gap-2">
                    {answers[answers.length-1]?.isCorrect ? <CheckCircle className="h-4 w-4"/> : <XCircle className="h-4 w-4"/>}
                    {answers[answers.length-1]?.isCorrect ? 'Correct!' : 'Incorrect'}
                </AlertTitle>
                <AlertDescription>{currentQuestion.feedback}</AlertDescription>
              </Alert>
              <Button onClick={handleNextQuestion} className="w-full">
                {currentQuestionIndex < examQuestions.length - 1 ? 'Next Question' : 'Finish Quiz'}
              </Button>
            </>
          ) : (
            <Button onClick={handleSubmitAnswer} disabled={selectedOption === null} className="w-full">
              Submit Answer
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}
