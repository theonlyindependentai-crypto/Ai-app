import Link from 'next/link';
import { caseLaw } from '@/lib/data';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';
import { Card } from '@/components/ui/card';

export default function CasesPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-headline text-3xl font-bold tracking-tight md:text-4xl">
          Case Law Analysis
        </h1>
        <p className="mt-2 text-muted-foreground">
          Explore full analysis of landmark cases relevant to Nigerian law.
        </p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search cases by name or citation..." className="pl-10" />
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Case Name</TableHead>
              <TableHead className="hidden sm:table-cell">Court</TableHead>
              <TableHead className="hidden md:table-cell">Year</TableHead>
              <TableHead className="text-right">Citation</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {caseLaw.map((c) => (
              <TableRow key={c.id}>
                <TableCell className="font-medium">
                  <Link href={`/cases/${c.slug}`} className="hover:underline text-primary">
                    {c.name}
                  </Link>
                </TableCell>
                <TableCell className="hidden sm:table-cell">{c.court}</TableCell>
                <TableCell className="hidden md:table-cell">{c.date}</TableCell>
                <TableCell className="text-right">
                  <Badge variant="outline">{c.citation}</Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
