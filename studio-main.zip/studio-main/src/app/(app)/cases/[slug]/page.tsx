import { notFound } from 'next/navigation';
import { caseLaw } from '@/lib/data';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

export async function generateStaticParams() {
  return caseLaw.map((c) => ({
    slug: c.slug,
  }));
}

type CaseDetailProps = {
  params: { slug: string };
};

export default function CaseDetailPage({ params }: CaseDetailProps) {
  const caseItem = caseLaw.find((c) => c.slug === params.slug);

  if (!caseItem) {
    notFound();
  }

  const sections = [
    { title: 'Facts of the Case', content: caseItem.facts },
    { title: 'Issues for Determination', content: caseItem.issues.map((issue, i) => <li key={i}>{issue}</li>), isList: true },
    { title: 'Decision of the Court', content: caseItem.decision },
    { title: 'Ratio Decidendi (Reasoning)', content: caseItem.ratio },
    { title: 'Relevance to Topic', content: caseItem.relevance },
  ];

  return (
    <div className="space-y-8">
      <div>
        <div className="flex flex-wrap items-center gap-2">
            <Badge variant="default">{caseItem.court}</Badge>
            <Badge variant="secondary">{caseItem.date}</Badge>
        </div>
        <h1 className="mt-2 font-headline text-4xl font-bold tracking-tight md:text-5xl">
          {caseItem.name}
        </h1>
        <p className="mt-4 max-w-3xl text-lg font-mono text-muted-foreground">
          {caseItem.citation}
        </p>
      </div>

      <div className="space-y-6">
        {sections.map((section, index) => (
            <Card key={section.title} className="overflow-hidden">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">{section.title}</CardTitle>
                </CardHeader>
                <CardContent>
                    {section.isList ? <ul className="list-disc list-inside space-y-2">{section.content}</ul> : <p>{section.content}</p>}
                </CardContent>
            </Card>
        ))}
      </div>
    </div>
  );
}
