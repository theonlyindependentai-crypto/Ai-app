'use client';

import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Paperclip, Send, Loader2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { actAsLegalTutor } from '@/ai/flows/act-as-legal-tutor';

type Message = {
  role: 'user' | 'assistant';
  content: string;
};

export default function TutorPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const result = await actAsLegalTutor({ query: input });
      const assistantMessage: Message = { role: 'assistant', content: result.explanation };
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.',
      };
      setMessages((prev) => [...prev, errorMessage]);
      console.error('Error with AI tutor:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const quickQuestions = [
    "Explain the concept of 'consideration' in contract law.",
    "What is the 'neighbour principle' in tort?",
    "Summarize the rule in Pinnel's Case.",
    "Differentiate between murder and manslaughter.",
  ];

  const handleQuickQuestion = (question: string) => {
    setInput(question);
    handleSubmit(new Event('submit') as any);
  }

  return (
    <div className="flex h-[calc(100vh-8rem)] flex-col">
       <div className="mb-4">
        <h1 className="font-headline text-3xl font-bold tracking-tight md:text-4xl">AI Legal Tutor</h1>
        <p className="mt-2 text-muted-foreground">
          Your personal Nigerian law lecturer. Ask me anything.
        </p>
      </div>

      <div className="flex-1 overflow-hidden">
        <ScrollArea className="h-full pr-4">
          <div className="space-y-4">
            {messages.length === 0 && (
                <Card className="border-dashed">
                    <CardHeader>
                        <CardTitle>Start the conversation</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="mb-4 text-sm text-muted-foreground">
                            Don't know where to start? Try one of these prompts:
                        </p>
                        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                            {quickQuestions.map((q, i) => (
                                <Button key={i} variant="outline" size="sm" className="h-auto justify-start text-left" onClick={() => setInput(q)}>
                                    <p className="whitespace-normal">{q}</p>
                                </Button>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex items-start gap-3 ${
                  message.role === 'user' ? 'justify-end' : ''
                }`}
              >
                {message.role === 'assistant' && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>AI</AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`prose prose-sm dark:prose-invert max-w-xl rounded-lg p-3 text-sm ${
                    message.role === 'user'
                      ? 'bg-primary text-primary-foreground prose-headings:text-primary-foreground prose-strong:text-primary-foreground'
                      : 'bg-muted'
                  }`}
                >
                  <ReactMarkdown>{message.content}</ReactMarkdown>
                </div>
                {message.role === 'user' && (
                  <Avatar className="h-8 w-8">
                     <AvatarImage src="https://images.unsplash.com/photo-1628260412297-a3377e45006f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxuaWdlcmlhbiUyMGxhdyUyMHN0dWRlbnR8ZW58MHx8fHwxNzY3OTE2MzgxfDA&ixlib=rb-4.1.0&q=80&w=1080" alt="User Avatar" />
                    <AvatarFallback>ME</AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            {isLoading && (
                 <div className="flex items-start gap-3">
                    <Avatar className="h-8 w-8">
                        <AvatarFallback>AI</AvatarFallback>
                    </Avatar>
                     <div className="max-w-xl rounded-lg p-3 text-sm bg-muted flex items-center gap-2">
                         <Loader2 className="h-4 w-4 animate-spin"/>
                         <span>Thinking...</span>
                     </div>
                 </div>
            )}
          </div>
        </ScrollArea>
      </div>

      <div className="mt-4 border-t pt-4">
        <form
          onSubmit={handleSubmit}
          className="relative flex items-center"
        >
          <Input
            type="text"
            value={input}
            onChange={handleInputChange}
            placeholder="Ask about a legal concept, case, or statute..."
            className="pr-24"
            disabled={isLoading}
          />
          <div className="absolute right-2 flex items-center gap-1">
            <Button type="button" size="icon" variant="ghost" disabled={isLoading}>
              <Paperclip className="h-4 w-4" />
              <span className="sr-only">Attach file</span>
            </Button>
            <Button type="submit" size="icon" variant="ghost" disabled={!input.trim() || isLoading}>
              <Send className="h-4 w-4" />
              <span className="sr-only">Send</span>
            </Button>
          </div>
        </form>
        <p className="mt-2 text-center text-xs text-muted-foreground">
          LexNaija AI can make mistakes. Consider checking important information.
        </p>
      </div>
    </div>
  );
}
