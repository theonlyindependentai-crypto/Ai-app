'use client';

import { useState, useRef } from 'react';
import Image from 'next/image';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Upload, FileText, Sparkles, AlertCircle, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Textarea } from '@/components/ui/textarea';
import { generateLegalSummaryFromImage } from '@/ai/flows/generate-legal-summary-from-image';

type AnalysisResult = {
  extractedLegalIssues: string;
  explanationUnderNigerianLaw: string;
  conciseSummary: string;
};

export default function ImageAnalysisPage() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [question, setQuestion] = useState('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!imagePreview) return;
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const analysis: AnalysisResult = await generateLegalSummaryFromImage({
        imageDataUri: imagePreview,
        question,
      });
      setResult(analysis);
    } catch (err) {
      console.error(err);
      setError('Failed to analyze the image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const triggerFileSelect = () => fileInputRef.current?.click();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-headline text-3xl font-bold tracking-tight md:text-4xl">
          Image Analysis
        </h1>
        <p className="mt-2 text-muted-foreground">
          Upload an image of your notes to get an AI-powered summary.
        </p>
      </div>

      <Card>
        <CardContent className="p-4 md:p-6">
          <div className="grid gap-6 md:grid-cols-2">
            <div
              className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed p-8 text-center"
              onClick={triggerFileSelect}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                accept="image/*"
              />
              {imagePreview ? (
                <div className="relative h-64 w-full">
                  <Image
                    src={imagePreview}
                    alt="Notes preview"
                    fill
                    className="rounded-md object-contain"
                  />
                </div>
              ) : (
                <>
                  <Upload className="h-12 w-12 text-muted-foreground" />
                  <h3 className="mt-4 font-semibold">Click to upload an image</h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    PNG, JPG, or WEBP recommended
                  </p>
                </>
              )}
            </div>
            <div className="space-y-4">
              <Textarea
                placeholder="Optional: Ask a specific question about the image content..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                className="h-32"
              />
              <Button
                onClick={handleAnalyze}
                disabled={!imagePreview || isLoading}
                className="w-full"
              >
                {isLoading ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Sparkles className="mr-2 h-4 w-4" />
                )}
                Analyze Notes
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Analysis Failed</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {result && (
        <Card>
          <CardContent className="p-4 md:p-6">
            <h2 className="mb-4 font-headline text-2xl font-semibold">Analysis Results</h2>
            <Accordion type="multiple" defaultValue={['issues', 'explanation', 'summary']} className="w-full">
              <AccordionItem value="issues">
                <AccordionTrigger className="text-lg font-semibold">
                  Extracted Legal Issues
                </AccordionTrigger>
                <AccordionContent className="prose prose-sm max-w-none dark:prose-invert">
                  {result.extractedLegalIssues}
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="explanation">
                <AccordionTrigger className="text-lg font-semibold">
                  Explanation Under Nigerian Law
                </AccordionTrigger>
                <AccordionContent className="prose prose-sm max-w-none dark:prose-invert">
                  {result.explanationUnderNigerianLaw}
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="summary">
                <AccordionTrigger className="text-lg font-semibold">
                  Concise Exam Summary
                </AccordionTrigger>
                <AccordionContent className="prose prose-sm max-w-none dark:prose-invert">
                  {result.conciseSummary}
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
