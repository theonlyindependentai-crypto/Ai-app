'use client';

import Link from 'next/link';
import Image from 'next/image';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  BookOpen,
  Camera,
  ClipboardCheck,
  MessageSquare,
  Notebook,
  ArrowRight,
} from 'lucide-react';
import { GavelIcon } from '@/components/icons';
import { PlaceHolderImages } from '@/lib/placeholder-images';

const features = [
  {
    title: 'AI Legal Tutor',
    description: 'Ask complex legal questions and get expert answers.',
    href: '/tutor',
    icon: MessageSquare,
    id: 'tutor',
  },
  {
    title: 'Browse Topics',
    description: 'Explore a comprehensive library of Nigerian law topics.',
    href: '/topics',
    icon: BookOpen,
    id: 'topics',
  },
  {
    title: 'Image Analysis',
    description: 'Turn your lecture notes into concise summaries instantly.',
    href: '/image-analysis',
    icon: Camera,
    id: 'image-analysis',
  },
  {
    title: 'Case Law',
    description: 'Access in-depth analysis of landmark Nigerian cases.',
    href: '/cases',
    icon: GavelIcon,
    id: 'case-law',
  },
  {
    title: 'Exam Section',
    description: 'Test your knowledge with interactive MCQs.',
    href: '/exam',
    icon: ClipboardCheck,
    id: 'exam',
  },
  {
    title: 'My Notes',
    description: 'Your personal vault for all saved materials.',
    href: '/notes',
    icon: Notebook,
    id: 'notes',
  },
];

export default function DashboardPage() {
  const featuresWithImages = features.map((feature) => ({
    ...feature,
    image: PlaceHolderImages.find((img) => img.id === feature.id),
  }));

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="font-headline text-3xl font-bold tracking-tight md:text-4xl">
          Welcome to LexNaija AI
        </h1>
        <p className="mt-2 text-muted-foreground">
          Your AI-powered guide to mastering Nigerian law.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        {featuresWithImages.map((feature) => (
          <Link href={feature.href} key={feature.title} className="group">
            <Card className="flex h-full flex-col overflow-hidden transition-all duration-300 ease-in-out hover:shadow-xl hover:-translate-y-1">
              {feature.image && (
                <div className="relative h-40 w-full overflow-hidden">
                  <Image
                    src={feature.image.imageUrl}
                    alt={feature.image.description}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                    data-ai-hint={feature.image.imageHint}
                  />
                </div>
              )}
              <CardHeader className="flex flex-row items-start gap-4">
                <div className="rounded-md bg-primary p-2 text-primary-foreground">
                  <feature.icon className="h-6 w-6" />
                </div>
                <div>
                  <CardTitle>{feature.title}</CardTitle>
                  <CardDescription className="mt-1">
                    {feature.description}
                  </CardDescription>
                </div>
              </CardHeader>
              <CardContent className="mt-auto flex justify-end">
                  <ArrowRight className="h-5 w-5 text-muted-foreground transition-transform duration-300 group-hover:translate-x-1" />
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
