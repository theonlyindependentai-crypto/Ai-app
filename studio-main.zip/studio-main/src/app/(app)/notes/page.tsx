'use client';

import { useState } from 'react';
import { userNotes as initialNotes } from '@/lib/data';
import type { Note } from '@/lib/types';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PlusCircle, MoreVertical, Edit, Trash2 } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

export default function NotesPage() {
  const [notes, setNotes] = useState<Note[]>(initialNotes);

  const handleDelete = (id: string) => {
    setNotes(notes.filter((note) => note.id !== id));
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-headline text-3xl font-bold tracking-tight md:text-4xl">
            My Notes
          </h1>
          <p className="mt-2 text-muted-foreground">
            Your personal revision vault, with all saved content.
          </p>
        </div>
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" />
          Create Note
        </Button>
      </div>

      {notes.length === 0 ? (
        <Card className="flex flex-col items-center justify-center p-12 text-center border-dashed">
            <CardHeader>
                <CardTitle>Your vault is empty</CardTitle>
                <CardDescription>
                    Notes from AI chats and topic summaries will be saved here automatically.
                </CardDescription>
            </CardHeader>
        </Card>
      ) : (
        <Card>
            <CardContent className="p-0">
                <Accordion type="single" collapsible className="w-full">
                {notes.map((note) => (
                    <AccordionItem value={note.id} key={note.id}>
                    <AccordionTrigger className="p-4 hover:no-underline">
                        <div className="flex w-full items-center justify-between pr-4">
                            <div className="text-left">
                                <h4 className="font-semibold">{note.title}</h4>
                                <div className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
                                <Badge variant="secondary">{note.course}</Badge>
                                <span>&middot;</span>
                                <span>{note.topic}</span>
                                <span>&middot;</span>
                                <span>{note.date}</span>
                                </div>
                            </div>
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                                <Button variant="ghost" size="icon">
                                    <MoreVertical className="h-4 w-4" />
                                </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                <DropdownMenuItem>
                                    <Edit className="mr-2 h-4 w-4" />
                                    Rename
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        handleDelete(note.id);
                                    }}
                                >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete
                                </DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </div>
                    </AccordionTrigger>
                    <AccordionContent className="p-4 pt-0">
                        <div className="prose prose-sm max-w-none rounded-md border bg-muted/50 p-4 dark:prose-invert">
                            <p>{note.content}</p>
                        </div>
                    </AccordionContent>
                    </AccordionItem>
                ))}
                </Accordion>
            </CardContent>
        </Card>
      )}
    </div>
  );
}
