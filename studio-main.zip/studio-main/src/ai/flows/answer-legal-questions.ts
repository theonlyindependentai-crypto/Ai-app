'use server';

/**
 * @fileOverview This file defines a Genkit flow for answering legal questions related to Nigerian law.
 *
 * It includes:
 * - `answerLegalQuestions`: The main function to call to get answers to legal questions.
 * - `AnswerLegalQuestionsInput`: The input type for the `answerLegalQuestions` function.
 * - `AnswerLegalQuestionsOutput`: The output type for the `answerLegalQuestions` function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnswerLegalQuestionsInputSchema = z.object({
  question: z.string().describe('The legal question to be answered, pertaining to Nigerian law.'),
});
export type AnswerLegalQuestionsInput = z.infer<typeof AnswerLegalQuestionsInputSchema>;

const AnswerLegalQuestionsOutputSchema = z.object({
  answer: z.string().describe('The answer to the legal question, citing relevant Nigerian law and cases.'),
});
export type AnswerLegalQuestionsOutput = z.infer<typeof AnswerLegalQuestionsOutputSchema>;

export async function answerLegalQuestions(input: AnswerLegalQuestionsInput): Promise<AnswerLegalQuestionsOutput> {
  return answerLegalQuestionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'answerLegalQuestionsPrompt',
  input: {schema: AnswerLegalQuestionsInputSchema},
  output: {schema: AnswerLegalQuestionsOutputSchema},
  prompt: `You are a Nigerian law lecturer and legal practitioner. Answer the following legal question to the best of your ability, citing relevant cases and legislation where applicable.\n\nQuestion: {{{question}}}`,
});

const answerLegalQuestionsFlow = ai.defineFlow(
  {
    name: 'answerLegalQuestionsFlow',
    inputSchema: AnswerLegalQuestionsInputSchema,
    outputSchema: AnswerLegalQuestionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
