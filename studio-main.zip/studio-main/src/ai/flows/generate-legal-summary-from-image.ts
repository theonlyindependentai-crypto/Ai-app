'use server';
/**
 * @fileOverview An AI agent that analyzes an image of legal notes, extracts legal issues, explains them under Nigerian law, and provides a concise summary for exam preparation.
 *
 * - generateLegalSummaryFromImage - A function that handles the image analysis and legal summarization process.
 * - GenerateLegalSummaryFromImageInput - The input type for the generateLegalSummaryFromImage function.
 * - GenerateLegalSummaryFromImageOutput - The return type for the generateLegalSummaryFromImage function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateLegalSummaryFromImageInputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      'An image of lecture notes or a textbook, as a data URI that must include a MIME type and use Base64 encoding. Expected format: \'data:<mimetype>;base64,<encoded_data>\'.' 
    ),
  question: z.string().optional().describe('Optional question about the legal issues in the image.'),
});
export type GenerateLegalSummaryFromImageInput = z.infer<typeof GenerateLegalSummaryFromImageInputSchema>;

const GenerateLegalSummaryFromImageOutputSchema = z.object({
  extractedLegalIssues: z.string().describe('The legal issues extracted from the image.'),
  explanationUnderNigerianLaw: z.string().describe('Explanation of the legal issues under Nigerian law.'),
  conciseSummary: z.string().describe('A concise summary of the content for exam preparation.'),
});
export type GenerateLegalSummaryFromImageOutput = z.infer<typeof GenerateLegalSummaryFromImageOutputSchema>;

export async function generateLegalSummaryFromImage(input: GenerateLegalSummaryFromImageInput): Promise<GenerateLegalSummaryFromImageOutput> {
  return generateLegalSummaryFromImageFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateLegalSummaryFromImagePrompt',
  input: {schema: GenerateLegalSummaryFromImageInputSchema},
  output: {schema: GenerateLegalSummaryFromImageOutputSchema},
  prompt: `You are an AI legal assistant specialized in Nigerian law. You will analyze the image of lecture notes or textbook content provided, extract the relevant legal issues, explain them under Nigerian law, and provide a concise summary suitable for exam preparation.

Image Content: {{media url=imageDataUri}}

Optional Question: {{question}}

Output Format:
1.  Extracted Legal Issues: [List of legal issues]
2.  Explanation Under Nigerian Law: [Detailed explanation of each issue with reference to relevant statutes and case law]
3.  Concise Summary: [A brief and exam-focused summary of the content]`, 
});

const generateLegalSummaryFromImageFlow = ai.defineFlow(
  {
    name: 'generateLegalSummaryFromImageFlow',
    inputSchema: GenerateLegalSummaryFromImageInputSchema,
    outputSchema: GenerateLegalSummaryFromImageOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
