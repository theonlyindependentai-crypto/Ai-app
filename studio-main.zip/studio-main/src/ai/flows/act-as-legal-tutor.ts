// Act as Nigerian Law lecturer.

'use server';

/**
 * @fileOverview An AI agent that acts as a Nigerian law lecturer.
 *
 * - actAsLegalTutor - A function that handles the legal tutoring process.
 * - ActAsLegalTutorInput - The input type for the actAsLegalTutor function.
 * - ActAsLegalTutorOutput - The return type for the actAsLegalTutor function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ActAsLegalTutorInputSchema = z.object({
  query: z.string().describe('The legal question or topic to be explained.'),
});
export type ActAsLegalTutorInput = z.infer<typeof ActAsLegalTutorInputSchema>;

const ActAsLegalTutorOutputSchema = z.object({
  explanation: z.string().describe('The explanation of the legal concept, formatted in Markdown.'),
});
export type ActAsLegalTutorOutput = z.infer<typeof ActAsLegalTutorOutputSchema>;

export async function actAsLegalTutor(input: ActAsLegalTutorInput): Promise<ActAsLegalTutorOutput> {
  return actAsLegalTutorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'actAsLegalTutorPrompt',
  input: {schema: ActAsLegalTutorInputSchema},
  output: {schema: ActAsLegalTutorOutputSchema},
  prompt: `You are an advanced AI legal tutor, equivalent to a 'ChatGPT 5' specialized in Nigerian law. Your purpose is to provide exceptionally detailed and comprehensive explanations of legal concepts.

  When a user asks a question, you must:
  1.  Provide a thorough and in-depth explanation of the legal concept.
  2.  Structure your answer logically using Markdown for formatting. Use subheadings (e.g., '## Subheading') to break down complex topics.
  3.  Use bullet points (e.g., '* Item 1') to list key principles, elements, or examples for clarity.
  4.  Maintain a professional, lecturer-like tone while being conversational and easy to understand.
  5.  Where relevant, briefly mention key statutes or landmark cases to support your explanation.

  Your entire response should be a single block of well-formatted Markdown text.

  Question: {{{query}}}
  `,
});

const actAsLegalTutorFlow = ai.defineFlow(
  {
    name: 'actAsLegalTutorFlow',
    inputSchema: ActAsLegalTutorInputSchema,
    outputSchema: ActAsLegalTutorOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
