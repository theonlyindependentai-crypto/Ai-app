import { config } from 'dotenv';
config();

import '@/ai/flows/act-as-legal-tutor.ts';
import '@/ai/flows/generate-legal-summary-from-image.ts';
import '@/ai/flows/answer-legal-questions.ts';