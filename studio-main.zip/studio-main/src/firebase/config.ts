export const firebaseConfig = {
  "projectId": "studio-5914467072-4b216",
  "appId": "1:43038720098:web:1677710e56266abba9913b",
  "apiKey": "AIzaSyDWRsDF2lCXQl9qReJTHuVh7eSC-e7kGYE",
  "authDomain": "studio-5914467072-4b216.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "43038720098"
};
