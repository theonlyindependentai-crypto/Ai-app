import type { LawTopic, CaseLaw, ExamQuestion, Note } from './types';

export const lawTopics: LawTopic[] = [
  {
    id: '1',
    slug: 'law-of-contract',
    title: 'Law of Contract',
    category: 'Private Law',
    overview:
      'The Nigerian Law of Contract governs agreements between parties, creating mutual obligations enforceable by law. It is primarily based on English common law, supplemented by Nigerian statutes and judicial precedents.',
    definitions: [
      {
        term: 'Contract',
        definition:
          'A legally binding agreement between two or more parties which, if it contains the elements of a valid legal agreement, is enforceable by law.',
      },
      {
        term: 'Offer',
        definition:
          'A definite promise to be bound on specific terms, made by one party (the offeror) to another (the offeree).',
      },
      { term: 'Acceptance', definition: 'An unqualified and final assent to the terms of an offer.' },
    ],
    essentialElements: [
      'Offer and Acceptance',
      'Intention to create legal relations',
      'Consideration',
      'Capacity to contract',
      'Legality of object',
    ],
    relevantStatutes: [{ name: 'Contracts Law of Lagos State, 2015', link: '#' }],
    leadingCases: [
      { name: 'Carlill v Carbolic Smoke Ball Co', citation: '[1893] 1 QB 256' },
      { name: 'Pharmaceutical Society of GB v Boots Cash Chemists', citation: '[1953] 1 QB 401' },
    ],
    examTips: [
      'Always use the ILAC (Issue, Law, Application, Conclusion) method for problem questions.',
      'Distinguish between an offer and an invitation to treat, using case law.',
      'Memorize the rules of consideration.',
    ],
    youtubeVideos: [
      { id: 'RvJh6j_813g', title: 'Nigerian Law of Contract - Introduction' },
      { id: '1ECj_t_F4QE', title: 'Elements of a Valid Contract' },
    ],
  },
  {
    id: '2',
    slug: 'law-of-torts',
    title: 'Law of Torts',
    category: 'Private Law',
    overview:
      'The Law of Torts deals with civil wrongs that cause someone else to suffer loss or harm, resulting in legal liability for the person who commits the tortious act. The primary tort is negligence.',
    definitions: [
      {
        term: 'Tort',
        definition: 'A civil wrong, other than a breach of contract, for which the law provides a remedy.',
      },
      { term: 'Negligence', definition: 'A breach of a legal duty of care which results in damage to the claimant.' },
    ],
    essentialElements: [
      'Duty of Care',
      'Breach of Duty',
      'Causation',
      'Remoteness of Damage (Damages must not be too remote)',
    ],
    relevantStatutes: [{ name: 'Civil Liability (Miscellaneous Provisions) Act', link: '#' }],
    leadingCases: [
      { name: 'Donoghue v Stevenson', citation: '[1932] AC 562' },
      { name: 'Heaven v Pender', citation: '(1883) 11 QBD 503' },
    ],
    examTips: [
      "Understand the 'neighbour principle' from Donoghue v Stevenson.",
      'Learn the tests for breach of duty, such as the standard of the reasonable man.',
      'Be able to discuss defences to negligence, like contributory negligence.',
    ],
    youtubeVideos: [
      { id: 'jS425KjFG5o', title: 'Introduction to the Law of Torts' },
      { id: 'u2yT1QjGkaA', title: 'The Tort of Negligence Explained' },
    ],
  },
  {
    id: '3',
    slug: 'constitutional-law',
    title: 'Constitutional Law',
    category: 'Public Law',
    overview:
      'Nigerian Constitutional Law is the body of law which defines the fundamental political principles, and establishes the structure, procedures, powers and duties of the government. It is centered around the Constitution of the Federal Republic of Nigeria 1999 (as amended).',
    definitions: [
      { term: 'Constitution', definition: 'The supreme law of the land, from which all other laws derive their validity.' },
      { term: 'Separation of Powers', definition: 'The division of governmental authority into three branches: legislative, executive, and judicial.' },
      { term: 'Federalism', definition: 'A system of government in which power is divided between a central government and regional governments.' },
    ],
    essentialElements: [
      'Supremacy of the Constitution (Section 1)',
      'Separation of Powers (Sections 4, 5, 6)',
      'Fundamental Human Rights (Chapter IV)',
      'Federal Character Principle',
    ],
    relevantStatutes: [{ name: 'Constitution of the Federal Republic of Nigeria, 1999', link: '#' }],
    leadingCases: [
      { name: 'A.G. Federation v. A.G. Abia State (No. 2)', citation: '(2002) 6 NWLR (Pt. 764) 542' },
      { name: 'Marbury v. Madison', citation: '5 U.S. 137 (1803) (for judicial review)' },
    ],
    examTips: [
      'Focus on the structure of government under the 1999 constitution.',
      'Memorize key sections, especially sections 1, 4, 5, and 6.',
      'Be prepared to discuss the enforcement of fundamental human rights.',
    ],
    youtubeVideos: [
      { id: '1uAMJd6pP4c', title: 'Supremacy of the Nigerian Constitution' },
      { id: 'Q_AlCjFkcsU', title: 'Separation of Powers in Nigeria' },
    ],
  },
];

export const caseLaw: CaseLaw[] = [
  {
    id: '1',
    slug: 'ag-federation-v-ag-abia-state',
    name: 'A.G. Federation v. A.G. Abia State (No. 2)',
    citation: '(2002) 6 NWLR (Pt. 764) 542',
    court: 'Supreme Court of Nigeria',
    date: '2002',
    facts:
      'The Federal Government of Nigeria sought to determine the seaward boundary of littoral states for the purpose of calculating revenue allocation from the Federation Account. The core issue was whether the revenue derived from offshore oil exploration should accrue to the federation or be shared with the states based on the derivation principle.',
    issues: [
      'What is the southern or seaward boundary of a littoral State within the Federal Republic of Nigeria?',
      'Whether the principle of derivation applies to revenue derived from resources located offshore.',
    ],
    decision:
      'The Supreme Court held that the seaward boundary of a littoral state for the purpose of calculating the amount of revenue accruing to the Federation Account directly from any natural resources derived from that State is the low-water mark of the land surface of such State or the seaward limits of inland waters within the State.',
    ratio:
      'The territory of Nigeria, including its maritime boundaries, is defined by the Constitution and international law. State boundaries do not extend beyond the low-water mark. Therefore, natural resources located in the continental shelf of Nigeria are deemed to be derived from the Federation and not from any specific State.',
    relevance:
      'This landmark case, often called the "Resource Control Suit," is fundamental to understanding Nigerian federalism, fiscal policy, and the constitutional limits of state territory in relation to natural resources.',
  },
  {
    id: '2',
    slug: 'carlill-v-carbolic-smoke-ball',
    name: 'Carlill v Carbolic Smoke Ball Co',
    citation: '[1893] 1 QB 256',
    court: 'Court of Appeal (England and Wales)',
    date: '1892',
    facts:
      'The Carbolic Smoke Ball Company placed an advertisement in a newspaper, promising to pay £100 to anyone who used their smoke ball as directed and still contracted influenza. To show their sincerity, they deposited £1,000 in a bank. Mrs. Carlill used the smoke ball as directed but still got the flu. She sued for the £100.',
    issues: [
      'Was the advertisement a binding promise (a unilateral offer) or mere advertising puff?',
      'Was there a valid acceptance of the offer?',
      'Was there consideration for the promise?',
    ],
    decision:
      'The Court of Appeal held that the advertisement was a unilateral offer to the entire world. The use of the smoke ball as directed constituted acceptance of the offer. The inconvenience suffered by Mrs. Carlill in using the product was sufficient consideration. Therefore, a binding contract was formed, and the company was liable to pay.',
    ratio:
      'An advertisement can constitute a unilateral offer which is accepted by performance of its conditions. The requirement for notification of acceptance can be waived in such offers. Depositing money in a bank can demonstrate an intention to be legally bound.',
    relevance:
      'This is a foundational case in the English and Nigerian law of contract, establishing the principles of unilateral offers, acceptance by performance, and the distinction between offers and "mere puff".',
  },
];

export const examQuestions: ExamQuestion[] = [
  {
    id: 'c1',
    topic: 'Law of Contract',
    question: 'Which of the following is NOT an essential element of a valid contract?',
    options: ['Offer and Acceptance', 'Consideration', 'A written agreement', 'Intention to create legal relations'],
    correctAnswer: 2,
    feedback: 'While many contracts are in writing, a written agreement is not a universal requirement. Oral contracts can be just as valid, provided the other essential elements are present.',
  },
  {
    id: 'c2',
    topic: 'Law of Contract',
    question: 'In contract law, an "invitation to treat" is:',
    options: [
      'A binding offer',
      'An invitation to negotiate or make an offer',
      'The acceptance of an offer',
      'A counter-offer',
    ],
    correctAnswer: 1,
    feedback:
      'An invitation to treat (e.g., goods displayed in a shop window) is merely an invitation for others to make an offer. It is not a binding offer itself. See Pharmaceutical Society v Boots Cash Chemists.',
  },
  {
    id: 'c3',
    topic: 'Law of Contract',
    question: "What is the legal principle established in Pinnel's Case?",
    options: [
      'Past consideration is no consideration.',
      'A promise to accept less than the full debt is not binding without fresh consideration.',
      'Consideration must move from the promisee.',
      'Performance of an existing duty is not good consideration.',
    ],
    correctAnswer: 1,
    feedback: "Pinnel's Case (1602) established that part payment of a debt on the due date is not good consideration for the creditor's promise to forgive the balance.",
  },
    {
    id: 'c4',
    topic: 'Law of Contract',
    question: 'A contract entered into by a minor for non-necessaries is generally:',
    options: [
      'Valid',
      'Void',
      'Voidable at the option of the minor',
      'Illegal',
    ],
    correctAnswer: 2,
    feedback: 'Contracts for non-necessary goods and services with a minor are generally voidable. The minor can choose to enforce the contract or repudiate it, but the adult party is bound.',
  },
  {
    id: 't1',
    topic: 'Law of Torts',
    question: "The 'neighbour principle' for establishing a duty of care was famously laid down in which case?",
    options: ['Carlill v Carbolic Smoke Ball Co', 'Heaven v Pender', 'Hedley Byrne v Heller', 'Donoghue v Stevenson'],
    correctAnswer: 3,
    feedback:
      "Lord Atkin in Donoghue v Stevenson [1932] AC 562 formulated the 'neighbour principle', stating you must take reasonable care to avoid acts or omissions which you can reasonably foresee would be likely to injure your neighbour.",
  },
  {
    id: 't2',
    topic: 'Law of Torts',
    question: 'What does the legal maxim "res ipsa loquitur" mean?',
    options: [
      'The thing speaks for itself',
      'To a willing person, injury is not done',
      'A new intervening act',
      'Let the master answer',
    ],
    correctAnswer: 0,
    feedback:
      '"Res ipsa loquitur" means "the thing speaks for itself." It is a rule of evidence in tort law that allows negligence to be inferred from the very nature of an accident or injury, in the absence of direct evidence on how the defendant behaved.',
  },
    {
    id: 't3',
    topic: 'Law of Torts',
    question: 'Which of these is a recognised defence to the tort of defamation?',
    options: [
      'Provocation',
      'Justification (Truth)',
      'Contributory negligence',
      'Mistake',
    ],
    correctAnswer: 1,
    feedback: 'Justification, or proving that the defamatory statement was substantially true, is a complete defence to a claim of defamation.',
  },
  {
    id: 'const1',
    topic: 'Constitutional Law',
    question: 'According to Section 1 of the 1999 Nigerian Constitution, the Constitution is:',
    options: [
        'Supreme and its provisions shall have binding force on all authorities and persons throughout the Federal Republic of Nigeria.',
        'Secondary to the Acts of the National Assembly.',
        'Advisory in nature.',
        'Applicable only to citizens and not to the government.'
    ],
    correctAnswer: 0,
    feedback: 'Section 1(1) of the 1999 Constitution of the Federal Republic of Nigeria establishes the principle of constitutional supremacy.'
  },
  {
    id: 'const2',
    topic: 'Constitutional Law',
    question: 'The legislative powers of the Federal Republic of Nigeria are vested in the:',
    options: [
        'President',
        'Supreme Court',
        'National Assembly',
        'Council of State'
    ],
    correctAnswer: 2,
    feedback: 'Section 4 of the 1999 Constitution vests the legislative powers of the Federation in the National Assembly, which consists of the Senate and the House of Representatives.'
  },
  {
    id: 'const3',
    topic: 'Constitutional Law',
    question: 'Chapter IV of the Nigerian Constitution deals with:',
    options: [
      'The Executive',
      'The Legislature',
      'Fundamental Human Rights',
      'The Judicature',
    ],
    correctAnswer: 2,
    feedback: 'Chapter IV of the 1999 Constitution of the Federal Republic of Nigeria is dedicated to outlining the fundamental rights of every citizen.'
  }
];

export const userNotes: Note[] = [
  {
    id: 'n1',
    title: 'Summary of Offer vs. ITT',
    course: 'Law of Contract',
    topic: 'Offer and Acceptance',
    date: '2024-05-10',
    content:
      'Key distinction: An offer is a definite promise to be bound (Carlill), while an Invitation to Treat (ITT) is an expression of willingness to negotiate. Examples of ITT: goods on display (Boots Cash), advertisements (Partridge v Crittenden), auctions.',
  },
  {
    id: 'n2',
    title: 'AI Analysis of Negligence Notes',
    course: 'Law of Torts',
    topic: 'Negligence',
    date: '2024-05-12',
    content:
      'Extracted from my lecture notes image: 1. Duty of Care (Donoghue v Stevenson neighbor principle). 2. Breach of Duty (standard of the reasonable man - Blyth v Birmingham Waterworks). 3. Causation (factual - "but for" test, Barnett v Chelsea; and legal - remoteness, The Wagon Mound).',
  },
];
