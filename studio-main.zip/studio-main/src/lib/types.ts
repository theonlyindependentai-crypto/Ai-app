export type LawTopic = {
  id: string;
  slug: string;
  title: string;
  category: string;
  overview: string;
  definitions: { term: string; definition: string }[];
  essentialElements: string[];
  relevantStatutes: { name: string; link: string }[];
  leadingCases: { name: string; citation: string }[];
  examTips: string[];
  youtubeVideos: { id: string; title: string }[];
};

export type CaseLaw = {
  id: string;
  slug: string;
  name: string;
  citation: string;
  court: string;
  date: string;
  facts: string;
  issues: string[];
  decision: string;
  ratio: string;
  relevance: string;
};

export type ExamQuestion = {
  id: string;
  topic: string;
  question: string;
  options: string[];
  correctAnswer: number;
  feedback: string;
};

export type Note = {
  id: string;
  title: string;
  date: string;
  course: string;
  topic: string;
  content: string;
};

export type ExamMode = 'timed' | 'infinity';

export type ExamSettings = {
  topic: string;
  mode: ExamMode;
};
