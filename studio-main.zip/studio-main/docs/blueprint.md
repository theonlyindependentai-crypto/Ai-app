# **App Name**: LexNaija AI

## Core Features:

- AI Legal Tutor: A conversational AI tutor specialized in Nigerian law, capable of explaining legal concepts, answering exam questions, and providing assignment help, acting as a Nigerian law lecturer and legal practitioner. The LLM powering the legal tutor can reason like a lawyer to make sure all relevant cases and legislation are included, making it function as a 'tool'.
- Browse Topics: A comprehensive legal learning center where users can browse Nigerian law topics by category and access topic overviews, definitions, essential elements, relevant statutes, leading Nigerian cases, and exam tips.
- Image Analysis: Users can upload images of lecture notes or textbooks, and the AI will analyze the image, extract legal issues, explain content under Nigerian law, answer questions, and convert content into short exam-ready notes.
- YouTube Integration: Shows topic-specific YouTube educational videos suitable for Nigerian law students, recommended by AI for concept clarity and exam revision.
- Full Case Law Analysis: Generates full Nigerian case analysis including facts, issues, decision, ratio decidendi, and relevance to topic.
- Exam Section: An interactive testing mode with multiple-choice questions based on Nigerian law, offering topic-based and mixed exams, timed and untimed modes, answer feedback, and performance tracking.
- Notes Topics: A personal revision vault that automatically saves AI chats, topic explanations, image analysis outputs, case law breakdowns, and exam explanations, organized by course, topic, and date, with editing, renaming, deleting, and offline revision capabilities.

## Style Guidelines:

- Primary color: Black (#000000), for a strong, authoritative feel.
- Secondary color: White (#FFFFFF), providing a clean and neutral backdrop.
- Accent color: Ash (#808080), offering a subtle contrast and modern aesthetic.
- Headline font: 'Playfair', serif, for elegant headlines; body font: 'PT Sans', sans-serif, for modern body text.
- Code font: 'Source Code Pro' for displaying code snippets.
- Use clean, modern icons relevant to Nigerian law topics and study modes, designed in shades of black, white, and ash.
- Subtle transitions and animations to enhance user experience and provide feedback during interactions, maintaining a minimalist aesthetic.